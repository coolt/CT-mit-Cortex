/* ------------------------------------------------------------------
 * --  _____       ______  _____                                    -
 * -- |_   _|     |  ____|/ ____|                                   -
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems    -
 * --   | | | '_ \|  __|  \___ \   Zurich University of             -
 * --  _| |_| | | | |____ ____) |  Applied Sciences                 -
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland     -
 * ------------------------------------------------------------------
 * --
 * -- Project     : Hamming-Code und Fehlerkorrektur
 * -- Description :
 * --
 * -- $Id: main.c 964 2014-11-13 12:44:13Z muln $
 * --------------------------------------------------------------- */
#include <utils_ctboard.h>
#include "hamming.h"

#define ADDR_LED_7_0         0x60000100
#define ADDR_LED_15_8        0x60000101
#define ADDR_DIP_SWITCH_7_0  0x60000200
#define ADDR_DIP_SWITCH_15_8 0x60000201

int main(void)
{
    uint8_t in_data, in_error, send;
    uint8_t out_data, receive;
    uint8_t corr;

    while (1) {
        /* read data from switches (b3 ... b0)*/
        in_data = read_byte(ADDR_DIP_SWITCH_7_0) & 0x0F;

        /* read error from switches (b3 ... b0)*/
        in_error = read_byte(ADDR_DIP_SWITCH_15_8) & 0x0F;

        /* data to be sent with 7/4 hamming code */
        send = encode(in_data);

        /* received data with error */
        receive = send ^ in_error;

        /* correct received data */
        corr = correct(receive);

        /* display data */
        out_data = (corr << 4) | (in_data & 0x0F);

        write_byte(ADDR_LED_7_0, out_data);
        write_byte(ADDR_LED_15_8, receive);
    }
}
