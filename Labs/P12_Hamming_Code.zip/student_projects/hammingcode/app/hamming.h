/* ------------------------------------------------------------------
 * --  _____       ______  _____                                    -
 * -- |_   _|     |  ____|/ ____|                                   -
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems    -
 * --   | | | '_ \|  __|  \___ \   Zurich University of             -
 * --  _| |_| | | | |____ ____) |  Applied Sciences                 -
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland     -
 * ------------------------------------------------------------------
 * --
 * -- Project     :
 * -- Description :
 * --
 * -- $Id: hamming.h 964 2014-11-13 12:44:13Z muln $
 * --------------------------------------------------------------- */
#include <stdint.h>

/* definitions */

#define P2_MASK 0x0E
#define P1_MASK 0x0D
#define P0_MASK 0x0B

/*******************************************************************/
/* public function prototypes */

uint8_t encode(uint8_t data);

uint8_t correct(uint8_t data);

/*******************************************************************/
