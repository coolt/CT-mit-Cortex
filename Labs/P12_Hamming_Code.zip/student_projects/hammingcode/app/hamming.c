/* ------------------------------------------------------------------
 * --  _____       ______  _____                                    -
 * -- |_   _|     |  ____|/ ____|                                   -
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems    -
 * --   | | | '_ \|  __|  \___ \   Zurich University of             -
 * --  _| |_| | | | |____ ____) |  Applied Sciences                 -
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland     -
 * ------------------------------------------------------------------
 * --
 * -- Project     :
 * -- Description :
 * --
 * -- $Id: hamming.c 964 2014-11-13 12:44:13Z muln $
 * --------------------------------------------------------------- */
#include "hamming.h"

/// STUDENTS: To be programmed



/// END: To be programmed

uint8_t even_parity(uint8_t data)
{
    /// STUDENTS: To be programmed



    /// END: To be programmed
}


uint8_t encode(uint8_t data)
{
    /// STUDENTS: To be programmed



    /// END: To be programmed
}


uint8_t correct(uint8_t data)
{
    /// STUDENTS: To be programmed



    /// END: To be programmed
}
